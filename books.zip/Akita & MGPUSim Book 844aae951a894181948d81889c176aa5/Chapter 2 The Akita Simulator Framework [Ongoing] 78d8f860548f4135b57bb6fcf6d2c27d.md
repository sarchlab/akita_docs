# Chapter 2. The Akita Simulator Framework [Ongoing]

[2.1 Time Management [Done]](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/2%201%20Time%20Management%20%5BDone%5D%208c6cfe79158144b2a459d710edf04af0.md)

[2.2 Component [Done]](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/2%202%20Component%20%5BDone%5D%202c031d940b1f49e8b9227a502f30684a.md)

[2.3 Smart Ticking [Done]](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/2%203%20Smart%20Ticking%20%5BDone%5D%20f28e11ee60de4f07855950164493980d.md)

[2.4 Hooking and Tracing [Ongoing]](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/2%204%20Hooking%20and%20Tracing%20%5BOngoing%5D%200b947051beb74868a2a74de81bafe40c.md)

[2.5 Data Recorder [Ongoing]](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/2%205%20Data%20Recorder%20%5BOngoing%5D%200b1033fe374b4621b01c40d7569e016a.md)

[The CLI](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/The%20CLI%2014919baeaf8680c9a583f447b2b5a7d7.md)

[Akita v4 Migration Guide](Chapter%202%20The%20Akita%20Simulator%20Framework%20%5BOngoing%5D%2078d8f860548f4135b57bb6fcf6d2c27d/Akita%20v4%20Migration%20Guide%20c7fb72701a0a4624a3ddb44d03dd3df3.md)