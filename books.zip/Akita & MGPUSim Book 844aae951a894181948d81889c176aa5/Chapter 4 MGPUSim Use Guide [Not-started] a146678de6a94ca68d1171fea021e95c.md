# Chapter 4. MGPUSim Use Guide [Not-started]

[ How to Use MGPUSim](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/How%20to%20Use%20MGPUSim%20443be4d6158e4ec1a1891f1e72673cd0.md)

[Repo Organization](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/Repo%20Organization%2081dff31765da45dd8a47d8622d03503b.md)

[Benchmarks & Main Programs](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/Benchmarks%20&%20Main%20Programs%20c4332df1c60f4287bd611dcb9fcd13d1.md)

[Command Line Arguments](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/Command%20Line%20Arguments%206742714d813e45558815604bc9fd9e65.md)

[Output Metrics](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/Output%20Metrics%20e0b09cf52be44733aa6128a6463f4cbb.md)

[I just Want To Dump a Trace](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/I%20just%20Want%20To%20Dump%20a%20Trace%20ea7bb7805205448eb95c99007514e191.md)

[I just Want to Modify a Parameter](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/I%20just%20Want%20to%20Modify%20a%20Parameter%20957f52c621dc49419aded833b5fe7c5e.md)

[Multi-GPU vs. Single GPU Simulation](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/Multi-GPU%20vs%20Single%20GPU%20Simulation%20513b6ec314404dab9e5973373ea5fd47.md)

[AkitaRTM: Real-Time Monitoring](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/AkitaRTM%20Real-Time%20Monitoring%2096f3a58b3106406099e8f935437f8fa3.md)

[MGPUSim: Preparing New Experiments](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/MGPUSim%20Preparing%20New%20Experiments%209b85ee8759064ddab8f0b745bab97057.md)

[MGPUSim: Behind the Scene](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/MGPUSim%20Behind%20the%20Scene%20c04a4968861a4f4481110fa15d0ee0fd.md)

[Developing MGPUSim](Chapter%204%20MGPUSim%20Use%20Guide%20%5BNot-started%5D%20a146678de6a94ca68d1171fea021e95c/Developing%20MGPUSim%2012919baeaf86804cb7b8c10121cf6307.md)