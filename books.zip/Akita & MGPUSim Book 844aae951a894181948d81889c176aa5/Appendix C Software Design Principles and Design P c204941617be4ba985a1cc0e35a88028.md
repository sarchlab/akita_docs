# Appendix C. Software Design Principles and Design Patterns

SOLID Principles

Singleton Pattern