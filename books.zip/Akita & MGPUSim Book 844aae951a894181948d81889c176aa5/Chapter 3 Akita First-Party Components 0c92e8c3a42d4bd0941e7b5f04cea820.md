# Chapter 3 Akita First-Party Components

[Memory Control Protocol](Chapter%203%20Akita%20First-Party%20Components%200c92e8c3a42d4bd0941e7b5f04cea820/Memory%20Control%20Protocol%2067910847110a477f980ecd7e534fb6da.md)

[Streaming Data Mover](Chapter%203%20Akita%20First-Party%20Components%200c92e8c3a42d4bd0941e7b5f04cea820/Streaming%20Data%20Mover%20f51359ed18d340639c67e0f609ce4414.md)