# Metrics Collection

[CPI Stack](Metrics%20Collection%209a55a9068afb4cd2a92af0b90e23d5da/CPI%20Stack%202fda3cab7503438dbe2b27820ceed867.md)